package Algorithms.BreadthFirstSearch;

import java.util.*;

public class GenericGraphBFS {

    private Map<Integer, List<Integer>> adjList ;

    public GenericGraphBFS(){
        adjList = new HashMap<>();
    }

    public void addEdge(int src, int dest){
        adjList.putIfAbsent(src, new ArrayList<>());
        adjList.get(src).add(dest);
    }

    public void bfs(int start){

        Set<Integer> visited = new HashSet<>();
        Queue<Integer> queue = new LinkedList<>();
        queue.add(start);
        visited.add(start);

        while(!queue.isEmpty()){
            int vertex = queue.poll();
            for(int neighbor : adjList.getOrDefault(vertex, new ArrayList<>())){
                if (!visited.contains(neighbor)) {
                    queue.add(neighbor);
                    visited.add(neighbor);
                }
            }
        }
    }

    public static void main(String[] args){
        GenericGraphBFS graph = new GenericGraphBFS();
        graph.addEdge(1, 2);
        graph.addEdge(1, 3);
        graph.addEdge(2, 4);
        graph.addEdge(2, 5);
        graph.addEdge(3, 6);
        graph.addEdge(3, 7);
    }
}
