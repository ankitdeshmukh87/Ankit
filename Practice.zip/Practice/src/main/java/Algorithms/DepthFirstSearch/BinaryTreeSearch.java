package Algorithms.DepthFirstSearch;


public class BinaryTreeSearch {
    public static void main(String[] args) {
        // Create the tree
        TreeNode root = new TreeNode(4);
        root.left = new TreeNode(2);
        root.right = new TreeNode(7);
        root.left.left = new TreeNode(1);
        root.left.right = new TreeNode(3);

        // Test the correct searchBST method
        TreeNode resultCorrect = searchBSTCorrect(root, 3);
        if (resultCorrect != null) {
            //System.out.println("Correct Method: Found node with value " + resultCorrect.val);
        } else {
            //System.out.println("Correct Method: Node not found");
        }
    }

    // Inner class to define the structure of the tree node
    static class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            val = x;
        }
    }

    // Correct implementation of searchBST
    public static TreeNode searchBSTCorrect(TreeNode root, int val) {
        // System.out.println("Correct search : "+ root.val);
        if (root == null) {
            return null;
        }
        if (root.val == val) {
            return root;
        }
        if (root.val > val) { // Search in the left subtree if val is less than root's value
            return searchBSTCorrect(root.left, val);
        } else { // Search in the right subtree if val is greater than root's value
            return searchBSTCorrect(root.right, val);
        }
    }

}
