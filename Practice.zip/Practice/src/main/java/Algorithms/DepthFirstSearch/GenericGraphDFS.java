package Algorithms.DepthFirstSearch;

public class GenericGraphDFS {

}
