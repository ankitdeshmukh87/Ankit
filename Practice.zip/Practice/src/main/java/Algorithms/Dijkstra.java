package Algorithms;

public class Dijkstra {
}
