package Algorithms.Sort;

public class MergeSort {
}
