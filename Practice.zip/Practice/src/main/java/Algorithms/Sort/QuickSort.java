package Algorithms.Sort;

public class QuickSort {
}
