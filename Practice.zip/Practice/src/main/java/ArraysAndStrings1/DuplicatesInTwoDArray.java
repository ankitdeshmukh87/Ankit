package ArraysAndStrings1;

import java.util.HashSet;

public class DuplicatesInTwoDArray {

    public static void main(String[] args) {
        int[][] twoDArray = {
                {1, 2, 3, 4},
                {5, 6, 7, 8},
                {9, 10, 1, 11},
                {12, 13, 14, 15}
        };
        printDuplicatesin2DArray(twoDArray);
    }

    public static void printDuplicatesin2DArray(int[][] twoDArray){

        HashSet<Integer> seen = new HashSet<>();
        HashSet<Integer> duplicates = new HashSet<>();

        for(int[] row : twoDArray){
            for(int element : row) {
                if(seen.contains(element))
                    duplicates.add(element);
                else {
                    seen.add(element);
                }
            }
        }

        if (!duplicates.isEmpty()) {
            for (int value : duplicates) {
                System.out.println(value);
            }
        }
    }
}
