package ArraysAndStrings1;

public class HappyNumber {

    public static void main(String[] args){
        int n = 7867;

        System.out.println(n%10);
        System.out.println(n/10);
    }
}
