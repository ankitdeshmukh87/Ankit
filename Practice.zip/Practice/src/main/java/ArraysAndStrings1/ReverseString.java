package ArraysAndStrings1;

public class ReverseString {


    public static void main(String[] args) {
        String inputString = "Voyager";
        ReverseString reverseString= new ReverseString();
        System.out.println(reverseString.reverseString(inputString));
    }

    public String reverseString(String inputStr) {
        char[] charArray = inputStr.toCharArray();
        StringBuilder finalString = new StringBuilder();
        for(int i= inputStr.length() -1; i!=-1; i--) {
            finalString.append(charArray[i]);
        }
        return finalString.toString();
    }
}
