package ArraysAndStrings1;

public class RotateOneDArray {

    public static void main(String[] args){
        int[] inputArray = {1, 2, 3, 4, 5, 6, 7};
        int k = 3;
    }
    public static void rotateArray(int[] arr, int k){

    }
}
