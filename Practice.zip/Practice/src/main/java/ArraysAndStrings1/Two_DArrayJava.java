package ArraysAndStrings1;

public class Two_DArrayJava {

    public static void main(String[] args){

        int[][] twoDArray = {
                {1,2,3},
                {3,4,5},
                {5,6,7}
        };
        printTwoDArray(twoDArray);
    }

    public static void printTwoDArray(int[][] twoDArray) {
        for(int[] row : twoDArray){
            for(int element : row){
                System.out.println(element + " ");
            }
            System.out.println();
        }
    }
}
