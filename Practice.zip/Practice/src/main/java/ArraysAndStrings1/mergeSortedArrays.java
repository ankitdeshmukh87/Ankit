package ArraysAndStrings1;

public class mergeSortedArrays {
    private static int[] nums1 = {1, 2, 3, 0, 0, 0};
    private static int[] nums2 = {2, 5, 6};

    public static void main(String[] args) {
        mergeSortedArrays(nums1, nums2, 3, 3);
    }

    public static void mergeSortedArrays(int[] nums1, int[] nums2, int m, int n){

        int ptr1 = m - 1;
        int ptr2 = n - 1;
        int ptr3 = nums1.length;

        for( ; ptr3>=0 && ptr1>=0 && ptr2>=0; ptr3--){
            if(nums1[ptr1]>=nums2[ptr2]){
                nums1[ptr3] = nums1[ptr1--];
            } else {
                nums1[ptr3] = nums1[ptr2--];
            }
        }

        while(ptr2>=0){
            nums1[ptr3] = nums2[ptr2--];
        }
    }

}
