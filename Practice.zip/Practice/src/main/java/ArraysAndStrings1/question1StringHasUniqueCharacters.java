package ArraysAndStrings1;

import java.util.Arrays;
import java.util.HashSet;

public class question1StringHasUniqueCharacters {

    public static void main(String[] args) {
        question1StringHasUniqueCharacters runner = new question1StringHasUniqueCharacters();
        System.out.println(runner.hasUniqueCharactersWithoutAdditionalDataStructure("apple"));
        System.out.println(runner.hasUniqueCharactersWithoutAdditionalDataStructure("abcdefghpple"));
        System.out.println(runner.hasUniqueCharactersWithoutAdditionalDataStructure("abcdefgh"));
        System.out.println(runner.hasUniqueCharactersWithAdditionalDataStructure("apple"));
        System.out.println(runner.hasUniqueCharactersWithAdditionalDataStructure("abcdefghpple"));
        System.out.println(runner.hasUniqueCharactersWithAdditionalDataStructure("abcdefgh"));
        System.out.println(runner.hasUniqueCharactersWithoutAdditionalDataStructureTwo("app"));
        System.out.println(runner.hasUniqueCharactersWithoutAdditionalDataStructureTwo("abcdefghppleTell"));
    }

    public boolean hasUniqueCharactersWithoutAdditionalDataStructure(String str) {

        for(int i=0; i<str.length() -1 ; i++ ) {
            char x = str.charAt(i);
            for(int j=i+1; j<str.length() -1 ; j++ ) {
                if (x == str.charAt(j))
                    return false;
            }
        }
        return true;
    }

    public boolean hasUniqueCharactersWithAdditionalDataStructure(String str) {
        HashSet<Character> hashSet = new HashSet<>();
        for(int i=0; i<str.length() -1 ; i++ ) {
            char x = str.charAt(i);
            if(hashSet.contains(x))
                return false;
        hashSet.add(str.charAt(i));
        }
        return true;
    }

    public boolean hasUniqueCharactersWithoutAdditionalDataStructureTwo(String str) {

        char[] charArray = str.toCharArray();
        Arrays.sort(charArray);
        for(int i=0; i<str.length() -1 ; i++ ) {
            if(charArray[i] == charArray[i+1]) {
                return false;
            }
        }
        return true;
    }

}
