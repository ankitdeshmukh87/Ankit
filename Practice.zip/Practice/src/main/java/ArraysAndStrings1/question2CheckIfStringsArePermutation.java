package ArraysAndStrings1;

import java.util.Arrays;

/*
Check Permutation: Given two strings, write a method to decide if one is a permutation of the
other.
 */
public class question2CheckIfStringsArePermutation {


    public static void main(String[] args) {
        question2CheckIfStringsArePermutation arePermutation =  new question2CheckIfStringsArePermutation();
        System.out.println(arePermutation.isPermutationNLogNSolution("apple","aplep"));
        System.out.println(arePermutation.isPermutationNLogNSolution("apple","aplle"));

        System.out.println(arePermutation.isPermutation("apple","aplep"));
        System.out.println(arePermutation.isPermutation("apple","aplle"));
    }

    public boolean isPermutationNLogNSolution(String one, String two) {
        if(one.length() != two.length()) return false;

        char[] strOneArray = one.toCharArray();
        char[] strTwoArray = two.toCharArray();
        Arrays.sort(strOneArray);
        Arrays.sort(strTwoArray);

        for(int i =0 ; i < strOneArray.length; i++) {
            if(strOneArray[i]!=strTwoArray[i])
                return false;
        }
        return true;
    }

    public boolean isPermutation(String one, String two) {
        if (one.length() != two.length()) return false;
        char[] charArray = new char[256];

        for(char c : one.toCharArray()) {
            charArray[c]++;
        }

        for(char b : two.toCharArray()) {
            charArray[b]--;
        }

        for(char c : charArray) {
            if(c>0)
                return false;
        }
        return true;
    }


}
