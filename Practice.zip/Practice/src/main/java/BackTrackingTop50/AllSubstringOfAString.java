package BackTrackingTop50;

import java.util.ArrayList;
import java.util.List;

/*
Generate all possible substrings of a given string, taking into account constraints like avoiding duplicates
 */
public class AllSubstringOfAString {
    public static void main(String[] args){
        String str = "abc";
        System.out.println(str.substring(0,1));
        // generateAllSubstringNonRecursive("abcd");
    }
    public static void generateAllStrings(String inputString, List<String> allStrings, int start, int end){

        int n = inputString.length();

        if(start<end){
            allStrings.add(inputString);
        }
    }

    public static List<String> generateAllSubstringNonRecursive(String inputString){
        List<String> listOfSubstrings = new ArrayList<>();

        for(int start = 0; start < inputString.length(); start++){
            for(int end = start + 1; end <= inputString.length(); end++){
                String subString = inputString.substring(start, end);
                listOfSubstrings.add(subString);
                System.out.println(subString);
            }
        }

        return listOfSubstrings;
    }
}
