package Backtracking;


import java.util.ArrayList;
import java.util.List;

public class GenerateAllSubsetsWithAGivenTargetValue {

    // Helper function to find all subsets with a given sum
    private static void findSubsetsWithSum(int[] arr, int index, int targetSum, List<Integer> currentSubset, List<List<Integer>> result) {
        // Base case: if targetSum is 0, add the currentSubset to result
        if (targetSum == 0) {
            result.add(new ArrayList<>(currentSubset));
            return;
        }

        // If we've reached the end of the array or targetSum becomes negative, return
        if (index == arr.length || targetSum < 0) {
            return;
        }

        // Include the current element in the subset
        currentSubset.add(arr[index]);
        findSubsetsWithSum(arr, index + 1, targetSum - arr[index], currentSubset, result);

        // Exclude the current element from the subset and backtrack
        currentSubset.remove(currentSubset.size() - 1);
        findSubsetsWithSum(arr, index + 1, targetSum, currentSubset, result);
    }

    public static List<List<Integer>> getSubsetsWithSum(int[] arr, int targetSum) {
        List<List<Integer>> result = new ArrayList<>();
        findSubsetsWithSum(arr, 0, targetSum, new ArrayList<>(), result);
        return result;
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 7};
        int targetSum = 6;

        List<List<Integer>> subsets = getSubsetsWithSum(arr, targetSum);
        System.out.println(subsets);  // Output: [[1, 2, 3]]
    }
}
