package Backtracking;

import java.util.ArrayList;
import java.util.List;

public class RobotInGrid {
    public static void main(String[] args) {
        int[][] grid = {
                {0, 0, 0, 0},
                {0, 1, 0, 0},
                {0, 0, 0, 0},
                {0, 0, 1, 0}
        };
        List<int[]> path = findPath(grid);
        if (path != null) {
            for (int[] p : path) {
                System.out.println("[" + p[0] + ", " + p[1] + "]");
            }
        } else {
            System.out.println("No path found");
        }
    }

    public static List<int[]> findPath(int[][] grid) {
        List<int[]> path = new ArrayList<>();
        if (grid == null || grid.length == 0) {
            return null;
        }
        boolean[][] visited = new boolean[grid.length][grid[0].length];
        if (dfs(grid, 0, 0, path, visited)) {
            return path;
        }
        return null;
    }

    private static boolean dfs(int[][] grid, int row, int col, List<int[]> path, boolean[][] visited) {
        // Check if out of bounds or at an obstacle or already visited
        if (row < 0 || col < 0 || row >= grid.length || col >= grid[0].length || grid[row][col] == 1 || visited[row][col]) {
            return false;
        }

        // Mark the cell as visited
        visited[row][col] = true;

        // Add the current cell to the path
        path.add(new int[]{row, col});

        // If the robot reaches the bottom-right corner
        if (row == grid.length - 1 && col == grid[0].length - 1) {
            return true;
        }

        // Explore the possible directions (right and down)
        if (dfs(grid, row, col + 1, path, visited) || dfs(grid, row + 1, col, path, visited)) {
            return true;
        }

        // Backtrack: remove the current cell from the path
        path.remove(path.size() - 1);
        return false;
    }
}

