package Backtracking;
/*
Sudoku is a number puzzle game played on a 9x9 grid, divided into nine 3x3 sub-grids or regions.
The goal is to fill in the grid so that:

Each row contains every number from 1 to 9 exactly once.
Each column contains every number from 1 to 9 exactly once.
Each 3x3 sub-grid contains every number from 1 to 9 exactly once.
 */
public class SudokuSolver {

    public void solveSudoku(char[][] board) {
        backtrack(board);
    }

    private boolean backtrack(char[][] board) {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (board[row][col] == '.') { // Find an empty cell
                    for (char num = '1'; num <= '9'; num++) { // Try digits 1 to 9
                        if (isValid(board, row, col, num)) {
                            board[row][col] = num; // Place the number
                            if (backtrack(board)) { // Recursively attempt to solve the rest of the board
                                return true; // If solved, return true
                            }
                            board[row][col] = '.'; // Reset and backtrack
                        }
                    }
                    return false; // No valid number found, need to backtrack
                }
            }
        }
        return true; // All cells are filled correctly
    }

    private boolean isValid(char[][] board, int row, int col, char num) {
        // Check the row
        for (int i = 0; i < 9; i++) {
            if (board[row][i] == num) return false;
        }

        // Check the column
        for (int i = 0; i < 9; i++) {
            if (board[i][col] == num) return false;
        }

        // Check the 3x3 sub-grid
        int startRow = row - row % 3;
        int startCol = col - col % 3;
        for (int i = startRow; i < startRow + 3; i++) {
            for (int j = startCol; j < startCol + 3; j++) {
                if (board[i][j] == num) return false;
            }
        }

        return true; // The number is valid
    }

    public static void main(String[] args) {
        SudokuSolver solver = new SudokuSolver();
        char[][] board = {
                {'5', '3', '.', '.', '7', '.', '.', '.', '.'},
                {'6', '.', '.', '1', '9', '5', '.', '.', '.'},
                {'.', '9', '8', '.', '.', '.', '.', '6', '.'},
                {'8', '.', '.', '.', '6', '.', '.', '.', '3'},
                {'4', '.', '.', '8', '.', '3', '.', '.', '1'},
                {'7', '.', '.', '.', '2', '.', '.', '.', '6'},
                {'.', '6', '.', '.', '.', '.', '2', '8', '.'},
                {'.', '.', '.', '4', '1', '9', '.', '.', '5'},
                {'.', '.', '.', '.', '8', '.', '.', '7', '9'}
        };
        solver.solveSudoku(board);
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }
}
