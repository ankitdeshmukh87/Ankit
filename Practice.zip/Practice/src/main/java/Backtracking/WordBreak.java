package Backtracking;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class WordBreak {

    public static void main(String[] args){

        List<String> wordDict = Arrays.asList("apple","pen","leet","code");
        WordBreak wordBreak = new WordBreak();
        wordBreak.wordBreak("leetcode",wordDict);
    }

    public boolean wordBreak(String inputStr, List<String> wordDict){

        int start = 0;
        int end = 0;
        int totalLength = 0;
        for(int i = 0; i < inputStr.length() ; end++) {
            if(wordDict.contains(inputStr.substring(start,end)) && end <inputStr.length()) {
                totalLength = totalLength + end;
                start = end;
            }
        }
        return totalLength == inputStr.length()?true:false;
    }

}
