package Backtracking;

import java.util.*;

/*
Problem : 77. Combinations
Given two integers n and k, return all possible combinations of k numbers chosen from the range [1, n].

You may return the answer in any order.
n = 1, 2, 3, 4
k = 2
 */
public class genrateAllPossibleCombinations {
        public static void main(String[] args) {
            int n = 4;
            int k = 2;
            List<List<Integer>> combinations = combine(n, k);

            // Print combinations
            /*for (List<Integer> combination : combinations) {
                System.out.println(combination);
            }*/
        }

        public static List<List<Integer>> combine(int n, int k) {
            List<List<Integer>> result = new ArrayList<>();
            backtrack(result, new ArrayList<>(), n, k, 1);
            return result;
        }

        private static void backtrack(List<List<Integer>> result, List<Integer> tempList, int n, int k, int start) {
            if (tempList.size() == k) {
                System.out.println(tempList.get(0) + " " + tempList.get(1));
                result.add(new ArrayList<>(tempList));
                return;
            }

            for (int i = start; i <= n; i++) {
                System.out.println(start);
                tempList.add(i);
                backtrack(result, tempList, n, k, i + 1);
                tempList.remove(tempList.size() - 1);
            }
        }

    public static List<List<Integer>> combineIterative(int n, int k) {
        List<List<Integer>> result = new ArrayList<>();
        Stack<List<Integer>> stack = new Stack<>();

        // Initialize stack with initial state
        stack.push(new ArrayList<>());

        while (!stack.isEmpty()) {
            List<Integer> current = stack.pop();

            // If the current combination has reached the required size k
            if (current.size() == k) {
                result.add(new ArrayList<>(current));
                continue;
            }

            // Determine the starting point for the next element
            int start = current.isEmpty() ? 1 : current.get(current.size() - 1) + 1;

            // Push new combinations to the stack
            for (int i = start; i <= n; i++) {
                List<Integer> next = new ArrayList<>(current);
                next.add(i);
                stack.push(next);
            }
        }

        return result;
    }
}

// backtrack(result, tempList, n, k, 1);
// backtrack(result, tempList(1), n, k, 2);
// backtrack(result, tempList(1,2), n, k, 3);
// backtrack(result{(1,2)}, tempList, n, k, 1);
// backtrack(result, tempList, n, k, 1);
// backtrack(result, tempList, n, k, 1);
// backtrack(result, tempList, n, k, 1);
// backtrack(result, tempList, n, k, 1);