package DDM;

import java.util.Arrays;

public class Problem {

    public static void main(String[] args) {
        Problem problem = new Problem();
        int[] inputArray = {5, 8, 7, 2, 3, 4, 6};
        int[] finalArr = problem.generatePeaksValleys(inputArray);
        // int[] finalArry = problem.generatePeaksValleysOpenAI(inputArray);
        for(int num : finalArr){
            System.out.print(num + " ");
        }
    }

    public int[] generatePeaksValleys(int[] inputArray) {

        Arrays.sort(inputArray); // Sort the array in increasing order
        int[] resultArray = new int[inputArray.length];
        int resultPtr = 0;
        int ptr = inputArray.length -1;
        int mid = inputArray.length/2;
        for(int i = 0 ; i <= mid && ptr > mid; i++,ptr--){
            System.out.println(inputArray[i] + " " + inputArray[ptr]);
            resultArray[resultPtr++] = inputArray[i]; // small value from beginning is copied
            resultArray[resultPtr++] = inputArray[ptr];// large value from end is copied
        }
        return resultArray;
    }

    public int[] generatePeaksValleysOpenAI(int[] inputArray) {
        Arrays.sort(inputArray); // Sort the array in increasing order
        int[] resultArray = new int[inputArray.length];
        int resultPtr = 0;
        int ptr = inputArray.length - 1;
        int mid = (inputArray.length - 1) / 2; // Adjusted mid calculation

        for (int i = 0; i <= mid; i++) {
            if (resultPtr < inputArray.length) {
                resultArray[resultPtr++] = inputArray[i]; // Small value from beginning is copied
            }
            if (resultPtr < inputArray.length && ptr > mid) {
                resultArray[resultPtr++] = inputArray[ptr--]; // Large value from end is copied
            }
        }

        return resultArray;
    }

}