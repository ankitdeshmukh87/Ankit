package Databases14.LinkedLists2;

class ListNodeDoublyLinkedList {
    int val;
    ListNodeDoublyLinkedList prev;
    ListNodeDoublyLinkedList next;

    public ListNodeDoublyLinkedList(int val) {
        this.val = val;
        this.prev = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    ListNodeDoublyLinkedList head;
    ListNodeDoublyLinkedList tail;

    public DoublyLinkedList() {
        this.head = null;
        this.tail = null;
    }

    // Method to insert a new node at the end of the list
    public void insertAtEnd(int val) {
        ListNodeDoublyLinkedList newNode = new ListNodeDoublyLinkedList(val);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    // Method to delete a node with given value
    public void delete(int val) {
        ListNodeDoublyLinkedList current = head;
        while (current != null) {
            if (current.val == val) {
                if (current.prev == null) { // If node to be deleted is the head
                    head = current.next;
                    if (head != null) {
                        head.prev = null;
                    } else { // If the list becomes empty after deletion
                        tail = null;
                    }
                } else if (current.next == null) { // If node to be deleted is the tail
                    tail = current.prev;
                    tail.next = null;
                } else { // Node to be deleted is in the middle
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                }
                return; // Exit the loop after deleting the first occurrence
            }
            current = current.next;
        }
    }

    // Method to print the linked list
    public void display() {
        ListNodeDoublyLinkedList current = head;
        while (current != null) {
            System.out.print(current.val + " ");
            current = current.next;
        }
        System.out.println();
    }
    public static void main(String[] args) {
        DoublyLinkedList myList = new DoublyLinkedList();

        // Insert elements into the linked list
        myList.insertAtEnd(1);
        myList.insertAtEnd(2);
        myList.insertAtEnd(3);
        myList.insertAtEnd(4);
        myList.insertAtEnd(5);

        // Display the linked list
        System.out.println("Linked List:");
        myList.display();

        // Delete an element
        myList.delete(3);

        // Display the linked list after deletion
        System.out.println("Linked List after deletion:");
        myList.display();
    }
}
