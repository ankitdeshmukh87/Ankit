package Databases14.LinkedLists2;

class ListNode {
    int val;
    ListNodeDoublyLinkedList next;

    public ListNode(int val) {
        this.val = val;
        this.next = null;
    }
}

class SinglyLinkedList {
    ListNodeDoublyLinkedList head;

    public SinglyLinkedList() {
        this.head = null;
    }

    // Method to insert a new node at the end of the list
    public void insertAtEnd(int val) {
        ListNodeDoublyLinkedList newNode = new ListNodeDoublyLinkedList(val);
        if (head == null) {
            head = newNode;
            return;
        }
        ListNodeDoublyLinkedList current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    // Method to delete a node with given value
    public void delete(int val) {
        if (head == null) {
            return;
        }
        if (head.val == val) {
            head = head.next;
            return;
        }
        ListNodeDoublyLinkedList current = head;
        while (current.next != null && current.next.val != val) {
            current = current.next;
        }
        if (current.next != null) {
            current.next = current.next.next;
        }
    }

    // Method to print the linked list
    public void display() {
        ListNodeDoublyLinkedList current = head;
        while (current != null) {
            System.out.print(current.val + " ");
            current = current.next;
        }
        System.out.println();
    }
    public static void main(String[] args) {
        SinglyLinkedList myList = new SinglyLinkedList();

        // Insert elements into the linked list
        myList.insertAtEnd(1);
        myList.insertAtEnd(2);
        myList.insertAtEnd(3);
        myList.insertAtEnd(4);
        myList.insertAtEnd(5);

        // Display the linked list
        System.out.println("Linked List:");
        myList.display();

        // Delete an element
        myList.delete(3);

        // Display the linked list after deletion
        System.out.println("Linked List after deletion:");
        myList.display();
    }
}

