package DesignPatterns;

public class Builder {
}
