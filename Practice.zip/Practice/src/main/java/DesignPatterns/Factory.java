package DesignPatterns;

public class Factory {
}
