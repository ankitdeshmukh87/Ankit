package DesignPatterns;

public class Observer {
}
