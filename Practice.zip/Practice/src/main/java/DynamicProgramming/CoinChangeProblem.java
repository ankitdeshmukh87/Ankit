package DynamicProgramming;

public class CoinChangeProblem {

    public static void main(String[] args) {

        int n = 100;
        int a = 10;
        int b = 5;
        System.out.println(possibleCombinations(100, 10, 5));
    }

    public static int possibleCombinations(int n, int a, int b) {
        int aRange = n/a;
        int bRange = 0;
        int count = 0 ;
        while(aRange >= 0 && bRange <=n/b) {
            if(a * aRange + b * bRange == n)
                count ++ ;
            aRange --;
            bRange ++;
        }
        return count;
    }
}



