package DynamicProgramming;
/*
F(n)=F(n−1)+F(n−2)
with initial conditions:
F(0)=0
F(1)=1
f(2) = f(1) + f(0);
*/

public class FibonacciSeries {

    public static void main(String[] args) {
        int n = 6;
        int[] memoizeArray = new int[n+1];
        FibonacciSeries fibonacciSeries = new FibonacciSeries();
        System.out.println(fibonacciSeries.fibonacciNumber(n, memoizeArray));
    }

    public int fibonacciNumber(int n, int[] array) {
        if(n==0 || n ==1)
            return n;
        array[0] = 0;
        array[1] = 1;
        for(int i = 2 ; i<=n ; i++) {
            array[i] = array[i - 1] + array[i - 2];
        }
        return array[n];
    }

}
