package DynamicProgramming;

/*
String A = 'abcdef'
String B = 'zgcdemnv'
Algorithm

1: Start with the one smaller in size and use its alphabets for comparison
2: 
 */
public class LongestCommonSubsequence {

    private static String A = "abcdef";
    private static String B = "zgcdemnv";
    
    public static void main(String[] args) {
        LongestCommonSubsequence longestCommonSubsequence = new LongestCommonSubsequence();
        //System.out.print(longestCommonSubsequence.longestSubsequence(A, B, 0));
        //longestCommonSubsequence.longestSubsequence("abcdef",0,A.length()-1, 0);
        longestCommonSubsequence.longestSubsequence("abcdef",0,A.length()-1);
    }
    /*public int longestSubsequence(String A, String B, int maximumSubsequencesLength) {
        if (A.length() == 0) {
            return 0;
        }
        if(B.contains(A) && maximumSubsequencesLength < A.length())
            maximumSubsequencesLength = A.length();
            return maximumSubsequencesLength;
        else if(!B.contains(A)) {
            return maximumSubsequencesLength;
        }
        return Math.max(longestSubsequence(A.substring(1), B, maximumSubsequencesLength),
                longestSubsequence(A.substring(A.length()-1),B, maximumSubsequencesLength));
    }*/

    /*public int longestSubsequence(String A,int m, int n, int maximumSubsequencesLength) {
        if (A.length() == 0) {
            return 0;
        }
        if(B.contains(A) && maximumSubsequencesLength < A.length()) {
            maximumSubsequencesLength = A.length();
            return maximumSubsequencesLength;
        }
        if( m < A.length() -1 && n > 0)
        {
            return Math.max(longestSubsequence(A.substring(m++, n), m , n, maximumSubsequencesLength),
                    longestSubsequence(A.substring(m, n--), m, n, maximumSubsequencesLength)) ;
        }
        return 0;
    }*/

    public void longestSubsequence(String A, int m, int n) {
        // Base case: if m or n is out of bounds or if the string is empty
        if (m >= A.length() || n < 0 || m > n) {
            return;
        }

        // Print the current substring
        System.out.println(A.substring(m, n + 1));

        // Recursively call the function with adjusted indices
        longestSubsequence(A, m + 1, n); // Move the start index to the right
        longestSubsequence(A, m, n - 1); // Move the end index to the left
    }
}
