package DynamicProgramming;

public class LongestIncreasingSubsequence {
    private static int[] array = {1,2,4,0,3,4,6,8};

    public static void main(String[] args) {
        System.out.print(lengthOfIncreasingSubsequence(LongestIncreasingSubsequence.array));
    }
    public static int lengthOfIncreasingSubsequence(int[] array) {
        int maxLength = 0;
        int length = 0;
        for(int i = 0 ; i < array.length - 1 ; i++){
            if(i+1 <= (array.length - 1) && array[i] <= array[i+1]) {
                length++;
            }
            else if(i+1 <= (array.length - 1) && array[i] > array[i+1]) {
                if (length > maxLength)
                    maxLength = length;
                length = 1;
            }
        }
        return Math.max(maxLength, length);
    }
}
