package DynamicProgramming;

public class RecursivelyAddElementsOfArray {

    static int[] Array = {3,6,1,4};
    public static void main(String[] args) {

        RecursivelyAddElementsOfArray addElementsOfArray = new RecursivelyAddElementsOfArray();
        System.out.println(addElementsOfArray.addElements(Array, 0,0));

    }

    static int addElements(int[] Arr, int total,int index ) {
        if(index == Arr.length) return total;
        total = total + Arr[index++];
        return addElements(Arr,total, index);
    }
}
