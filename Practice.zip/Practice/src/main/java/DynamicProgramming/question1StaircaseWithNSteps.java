package DynamicProgramming;

public class question1StaircaseWithNSteps {


    public static void main(String[] args) {
        int n = 10 ;
        int step1 = 1;
        int step2 = 2;
        int step3 = 5;
        question1StaircaseWithNSteps question1StaircaseWithNSteps = new question1StaircaseWithNSteps();
        System.out.println(question1StaircaseWithNSteps.countPossibleWaysBruteForce(10,step1,step2,step3));
    }

    public int countPossibleWaysBruteForce(int n, int steps1, int steps2, int steps3) {
        int countWays = 0;
        for (int i = 0; i <= n / steps1; i++) {
            for (int j = 0; j <= n / steps2; j++) {
                for (int k = 0; k <= n / steps3; k++) {
                    int totalSteps = steps1 * i + steps2 * j + steps3 * k;
                    if (totalSteps == n) {
                        countWays++;
                    }
                }
            }
        }
        return countWays;
    }



}
