package GenericPractice;

import java.util.Stack;

public class InitializationOfDataStructures {

    private static Stack<Integer> mainStack ;
    private static Stack<Integer> secondStack ;

    private static int stackPos;

    public static void main(){
        stackPos = 0;
        mainStack = new Stack<>();
        secondStack = new Stack<>();
    }

    public void push(int val){
        mainStack.push(val);
        stackPos++;
    }

    public int pop() {
        return mainStack.pop();
    }
    
}
