package GenericQuestions;

/*
Question and the algo to solve

Given a 2D array where each sub-array represents a meeting with a start time and an end time,
you need to determine if there is any overlap between the meetings.
If any two meetings overlap, return true; otherwise, return false.

Here's a step-by-step approach to solving this problem in Java:

1: Sort the Meetings: First, sort the array by the start times of the meetings.
2: Check for Overlaps: Iterate through the sorted list and check if the end time of the current
meeting is greater than the start time of the next meeting.

 */

import java.util.Arrays;
import java.util.Comparator;

public class OverlappingMeetings {

    public static void main() {
        int[][] meetings = {
                {1, 5},
                {6, 10},
                {5, 6},
                {2, 3}
        };
        System.out.println(overlappingMeetings(meetings));
    }

    public static boolean overlappingMeetings(int[][] meetings) {
        if (meetings == null || meetings.length == 0) {
                return false;
        }
        // Sort the meetings by start time
        Arrays.sort(meetings, Comparator.comparingInt(a -> a[0]));
        for (int i = 1; i < meetings.length; i++) {
            // If the end time of the previous meeting is greater than the start time of the current meeting
            if (meetings[i - 1][1] > meetings[i][0]) {
                return true; // Overlap found
            }
        }
        return false;
    }
}
