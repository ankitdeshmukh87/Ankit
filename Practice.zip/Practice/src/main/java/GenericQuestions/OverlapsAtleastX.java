package GenericQuestions;

public class OverlapsAtleastX {

    public static void main(String[] args) {
        int[] inputArr = {4,10,2,6,3};
        OverlapsAtleastX caller = new OverlapsAtleastX();
        System.out.println(caller.arraysOverlap(inputArr));
    }

    private boolean arraysOverlap(int[] inputArr) {
        int start1 = inputArr[0];
        int end1 = inputArr[1];
        int start2 = inputArr[2];
        int end2 = inputArr[3];
        int overlapSize = inputArr[4];

        int overlapStart = Math.max(start1, start2);
        int overlapEnd = Math.max(end1, end2);

        int diff = overlapEnd - overlapStart + 1;
        return overlapSize >= diff;
    }
}
