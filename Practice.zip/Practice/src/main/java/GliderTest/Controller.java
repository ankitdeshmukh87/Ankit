package GliderTest;

public class Controller {

    public String doAction() {
        return "action";
    }

    public String doOtherAction() {
        return "action";
    }
}
