package GliderTest;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ControllerTest {
    private Controller controller ;

    @Test
    public void test() {
        assertNotNull(controller.doAction());
        assertEquals("action", controller.doAction());
        assertEquals("otherAction", controller.doOtherAction());
    }
}
