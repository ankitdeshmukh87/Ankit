/*
package GliderTest;

import java.util.*;
import java.io.*;
import java.math.*;
class Outcome {
    */
/*
     * Implement method/function with name 'solve' below.
     * The function accepts following as parameters.
     * 1. a is of type List<Integer>.
     * 2. K is of type int.
     * return int.
     *//*

    public static int solve(List<Integer> a,int K){
//Write your code here
        return; //return type "int".
    }
}
public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getProperty("OUTPUT_FILE_PATH")));
        bufferedWriter.write("\n");
        bufferedWriter.close();
        bufferedWriter = new BufferedWriter(new FileWriter(System.getProperty("OUTPUT_FILE_PATH"),true));
        int aCount = Integer.parseInt(bufferedReader.readLine().trim());
        List<Integer> a = new ArrayList<>();
        String[] atempItems = bufferedReader.readLine().replaceAll("\\s+$", "").split(" ");
        for (int i = 0; i < aCount; i++) {
            int aItem = Integer.parseInt(atempItems[i]);
            a.add(aItem);
        }
        int K = Integer.parseInt(bufferedReader.readLine().trim());
        int outcome = Outcome.solve(a,K);
        bufferedWriter.write(outcome + "\n");
        bufferedWriter.newLine();
        bufferedReader.close();
        bufferedWriter.close();
    }
}*/
