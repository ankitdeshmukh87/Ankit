package HashMap;

import java.util.HashMap;

public class MajorityElement {

        public int majorityElement(int[] nums) {
            HashMap<Integer, Integer> frequencyMap = new HashMap<>();
            int n = nums.length;

            // Build the frequency map
            for (int num : nums) {
                frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
            }

            // Find the majority element
            for (int num : frequencyMap.keySet()) {
                if (frequencyMap.get(num) > n / 2) {
                    return num;
                }
            }

            // In case there's no majority element, but given the problem guarantees a majority element, this line is not required
            throw new IllegalArgumentException("No majority element found.");
        }

        public static void main(String[] args) {
            MajorityElement finder = new MajorityElement();
            int[] nums = {3, 2, 3};
            System.out.println(finder.majorityElement(nums)); // Output: 3
        }

}
