package HashMap;

/*
Given two strings ransomNote and magazine, return true if ransomNote can be constructed by using the
letters from magazine and false otherwise.

Each letter in magazine can only be used once in ransomNote.

Example 1:

Input: ransomNote = "a", magazine = "b"
Output: false
Example 2:

Input: ransomNote = "aa", magazine = "ab"
Output: false
 */

import java.util.HashMap;

public class RansomNote {
    public static void main(String[] args){
        String ransomNote = "";
        String magazine = "";

        System.out.println(canConstruct("a","b"));
    }

    public static boolean canConstruct(String ransomNote, String magazine) {
        int[] magazineCount  = new int[26];

        for(char c: magazine.toCharArray()){
            magazineCount [c - 'a']++;
        }

        for(char c : ransomNote.toCharArray()){
            if(magazineCount [c - 'a'] > 0)
                magazineCount [c - 'a']--;
            else{
                return false;
            }
        }
        return true;
    }


    public static boolean canConstructHashMap(String ransomNote, String magazine) {
        HashMap<Character,Integer> hashMap = new HashMap<>();

        for(char c: magazine.toCharArray()){
            hashMap.put(c, hashMap.getOrDefault(c,0) + 1);
        }

        for(char c : ransomNote.toCharArray()){
            if(hashMap.getOrDefault(c,0) > 0)
                hashMap.put(c,hashMap.getOrDefault(c,0) - 1);
            else
                return false;
        }
        return true;
    }

}
