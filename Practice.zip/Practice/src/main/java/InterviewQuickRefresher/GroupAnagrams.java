package InterviewQuickRefresher;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class GroupAnagrams {

    public static void main(String[] args) {
        String[] stringArray = {
                "eat","tea","tan","ate","nat","bat"
        };

    }

    public static List<List<String>> groupAnagrams(String[] stringArray){

        HashMap<String, List<String>> hashMap = new HashMap<>();
        for(String str : stringArray) {
            char[] charArray = str.toCharArray();
            Arrays.sort(charArray);
            String sortedStr = new String(charArray);
            hashMap.computeIfAbsent(sortedStr, k -> new ArrayList<>()).add(str);
        }
        return new ArrayList<>(hashMap.values());
    }
}
