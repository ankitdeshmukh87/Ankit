package InterviewQuickRefresher;
/*
You are given two integer arrays nums1 and nums2, sorted in non-decreasing order, and two integers m and n,
representing the number of elements in nums1 and nums2 respectively.

Merge nums1 and nums2 into a single array sorted in non-decreasing order.

The final sorted array should not be returned by the function, but instead be stored inside the array nums1.
To accommodate this, nums1 has a length of m + n, where the first m elements denote the elements that should be merged, and the last n elements are set to 0 and should be ignored. nums2 has a length of n.
 */
public class MergeSortedArrays {

    public static void main(String[] args){
        int[] nums1 = {1,2,3,0,0,0};
        int[] nums2= {2,5,6};
        int m = nums1.length;
        int n = nums2.length;
    }

    public static void mergerArrays(int[] nums1, int[] nums2, int m , int n){
        int ptr1 = m - 1;
        int ptr2 = n - 1;
        int  ptr3 = nums1.length - 1;
        for(  ; ptr3 >=0 && ptr1 >=0 && ptr2 >=0 ; ptr3--){
            if(nums1[ptr1]>=nums2[ptr2]){
                nums1[ptr3] = nums1[ptr1--];
            } else {
                nums1[ptr3] = nums2[ptr2--];
            }
        }

        while (ptr2 >= 0) {
            nums1[ptr3--] = nums2[ptr2--];
        }
    }

}
