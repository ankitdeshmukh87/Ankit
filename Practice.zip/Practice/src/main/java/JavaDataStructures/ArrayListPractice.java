package JavaDataStructures;

import java.util.*;

public class ArrayListPractice {

    public static void main(String[] args) {
        ArrayList arrayList = new ArrayList();
        Queue queue = new LinkedList();
        arrayList.add(1);
        arrayList.add(1,3);
        arrayList.get(2);
        HashMap<Integer, Integer> hashMap = new HashMap<>();
        HashSet<Integer> hashSet = new HashSet<>();
        // Appends all of the elements in the specified collection to the end of this list, in the order
        // that they are returned by the specified collection's Iterator
        //


    }
}
