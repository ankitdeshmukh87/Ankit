package JavaDataStructures;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class DSPrep {

    int[] arr = new int[5];

    private ArrayList arrayList = new ArrayList();
    LinkedList linkedList = new LinkedList();

    Hashtable hashtable = new Hashtable();
    HashMap hashMap = new HashMap();
    ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
    LinkedHashMap linkedHashMap = new LinkedHashMap();
    TreeMap treeMap = new TreeMap();

    HashSet hashSet = new HashSet();
    LinkedHashSet linkedHashSet = new LinkedHashSet();
    TreeSetPractice treeSetPractice = new TreeSetPractice();

    PriorityQueue priorityQueue = new PriorityQueue();
    ArrayDeque arrayDeque = new ArrayDeque();

    StackUsage stack = new StackUsage();
    Stack<Integer> stack1 = new Stack<>();

    // Arrays 1D, 2D and 3D

    // 2D Array initialization
    int[][] a = {
            {1, 2, 3},
            {4, 5, 6, 9},
            {7},
    };


    // x = depth, y = rows , z = columns
    int x =3, y=3, z=3;
    int[][] twoDArray = new int[x][y];
    int[][][] threeDArray = new int[x][y][z];


    // Populate the array with values

    public static void main(String[] args) {

    }

    public void arrayListOperations() {
      arrayList.add(1);
    }

}
