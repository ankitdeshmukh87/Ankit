package JavaDataStructures.DataStructureClassesImplementation;

import java.util.Arrays;

public class ArrayListImpl<E> {
    private Object[] elementData; // Array to hold elements
    private int size; // Number of elements

    public ArrayListImpl() {
        elementData = new Object[10]; // Default capacity
        size = 0;
    }

    public void add(E e) {
        ensureCapacity();
        elementData[size++] = e;
    }

    private void ensureCapacity() {
        if (size == elementData.length) {
            int newCapacity = elementData.length * 2;
            elementData = Arrays.copyOf(elementData, newCapacity);
        }
    }

    public E get(int index) {
        return (E) elementData[index];
    }

    public E remove(int index) {
        E oldValue = (E) elementData[index];
        int numMoved = size - index - 1;
        if (numMoved > 0) {
            System.arraycopy(elementData, index + 1, elementData, index, numMoved);
        }
        elementData[--size] = null;
        return oldValue;
    }
}
