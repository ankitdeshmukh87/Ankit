package JavaDataStructures.DataStructureClassesImplementation;

public class HashMapImpl<K, V> {
    static class Node<K, V> {
        final K key;
        V value;
        Node<K, V> next;

        Node(K key, V value, Node<K, V> next) {
            this.key = key;
            this.value = value;
            this.next = next;
        }
    }

    private Node<K, V>[] table;
    private int size;
    private static final int INITIAL_CAPACITY = 16;

    public HashMapImpl() {
        table = new Node[INITIAL_CAPACITY];
        size = 0;
    }

    public V put(K key, V value) {
        int hash = key.hashCode();
        int index = hash % table.length;
        Node<K, V> newNode = new Node<>(key, value, null);
        Node<K, V> existing = table[index];
        if (existing == null) {
            table[index] = newNode;
        } else {
            Node<K, V> current = existing;
            while (current.next != null && !current.key.equals(key)) {
                current = current.next;
            }
            if (current.key.equals(key)) {
                current.value = value;
            } else {
                current.next = newNode;
            }
        }
        size++;
        if (size > table.length * 0.75) {
            resize();
        }
        return value;
    }

    private void resize() {
        Node<K, V>[] newTable = new Node[table.length * 2];
        for (Node<K, V> node : table) {
            while (node != null) {
                int index = node.key.hashCode() % newTable.length;
                Node<K, V> next = node.next;
                node.next = newTable[index];
                newTable[index] = node;
                node = next;
            }
        }
        table = newTable;
    }

    public V get(K key) {
        int hash = key.hashCode();
        int index = hash & (table.length - 1);
        Node<K, V> node = table[index];
        while (node != null) {
            if (node.key.equals(key)) {
                return node.value;
            }
            node = node.next;
        }
        return null; // Key not found
    }

    public V remove(K key) {
        int hash = key.hashCode();
        int index = hash & (table.length - 1);
        Node<K, V> previous = null;
        Node<K, V> current = table[index];
        while (current != null) {
            if (current.key.equals(key)) {
                if (previous == null) {
                    table[index] = current.next;
                } else {
                    previous.next = current.next;
                }
                size--;
                return current.value;
            }
            previous = current;
            current = current.next;
        }
        return null; // Key not found
    }

    public int size() {
        return size;
    }
}
