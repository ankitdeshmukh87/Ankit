package JavaDataStructures.DataStructureClassesImplementation;

public class LinkedListImpl<E> {
    private class Node {
        E item;
        Node next;
        Node prev;

        Node(Node prev, E element, Node next) {
            this.item = element;
            this.next = next;
            this.prev = prev;
        }
    }

    private Node first;
    private Node last;
    private int size;

    public LinkedListImpl() {
        first = null;
        last = null;
        size = 0;
    }

    public void add(E e) {
        Node l = last;
        Node newNode = new Node(l, e, null);
        last = newNode;
        if (l == null) {
            first = newNode;
        } else {
            l.next = newNode;
        }
        size++;
    }

    public E get(int index) {
        Node x = node(index);
        return x.item;
    }

    private Node node(int index) {
        Node x = first;
        for (int i = 0; i < index; i++) {
            x = x.next;
        }
        return x;
    }

    public E remove(int index) {
        Node x = node(index);
        E item = x.item;
        Node prev = x.prev;
        Node next = x.next;
        if (prev == null) {
            first = next;
        } else {
            prev.next = next;
            x.prev = null;
        }
        if (next == null) {
            last = prev;
        } else {
            next.prev = prev;
            x.next = null;
        }
        size--;
        return item;
    }
}

