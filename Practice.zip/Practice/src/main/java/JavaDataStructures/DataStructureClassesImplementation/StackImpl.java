package JavaDataStructures.DataStructureClassesImplementation;

import java.util.ArrayList;

public class StackImpl<E> {
    private ArrayList<E> list = new ArrayList<>();

    public E push(E item) {
        list.add(item);
        return item;
    }

    public E pop() {
        int lastIndex = list.size() - 1;
        E obj = list.get(lastIndex);
        list.remove(lastIndex);
        return obj;
    }

    public E peek() {
        int lastIndex = list.size() - 1;
        return list.get(lastIndex);
    }
}
