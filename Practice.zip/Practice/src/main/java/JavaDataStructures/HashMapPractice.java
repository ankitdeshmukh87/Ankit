package JavaDataStructures;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/*
HashMap does not allow duplicate keys.
Each key in a HashMap must be unique. If you try to insert a new key-value pair where the key already exists in the map,
the new value will replace the old value associated with that key.

Inserting a Key-Value Pair:
If Key Does Not Exist: The key-value pair is added to the HashMap.
If Key Already Exists: The value associated with the existing key is updated with the new value.

Internal Mechanism
    put(K key, V value) Method:
        Computes the hash code of the key to determine the bucket index.
        Checks if the key already exists in the bucket.
        If the key exists, updates the value.
        If the key does not exist, inserts a new entry.


 */
public class HashMapPractice {
    public static void main(String[] args) {

        HashMap<Integer, Integer> hashMap = new HashMap<>();
        HashMap<Integer, Integer> hashMap2 = new HashMap<>();
        ArrayList<Integer> arrayList = new ArrayList<>();
        //1: To add a new key value entry
        hashMap.put(3,4);
        //2: Copies all of the mappings from the specified map to this map.
        // These mappings will replace any mappings that this map had for any of the keys currently in the specified map
        hashMap.putAll(hashMap2); // it only accepts map not set or arraylist
        //3: Returns the value to which the specified key is mapped, or null if this map contains no mapping for the key.
        hashMap.get(3);
        //4: Returns a Collection view of the values contained in this map. The collection is backed by the map,
        // so changes to the map are reflected in the collection, and vice-versa
        hashMap.values();
        //5:Returns a Set view of the keys contained in this map. The set is backed by the map, so changes to
        // the map are reflected in the set, and vice-versa
        hashMap.keySet();
        //6: If the specified key is not already associated with a value (or is mapped to null) associates it with
        // the given value and returns null, else returns the current value.
        hashMap.putIfAbsent(3,4);
        //7: Returns the value to which the specified key is mapped, or defaultValue if this map contains no mapping for the key
        hashMap.getOrDefault(3,4);
        //8:If the specified key is not already associated with a value (or is mapped to null), attempts to compute its
        // value using the given mapping function and enters it into this map unless null.
        hashMap.computeIfAbsent(1, k -> 2000 + 33000);
        //9: If the value for the specified key is present and non-null, attempts to compute a new mapping
        // given the key and its current mapped value.
        hashMap.computeIfPresent(1, (key, val) -> val + 100);

        hashMap.replace(1,3,4);
        hashMap.replace(2,4);
        hashMap.isEmpty();
        hashMap.containsKey(1);
        hashMap.containsValue(4);

        Map<String, Integer> hashMap3 = new HashMap<>();

        // Adding key-value pairs
        hashMap3.put("Apple", 10);
        hashMap3.put("Banana", 20);
        hashMap3.put("Orange", 30);
        hashMap3.put("Apple", 15);
        System.out.println("HashMap3: " + hashMap3);


        Map<String, List<Integer>> multiValueMap = new HashMap<>();

        // Adding values to the key "Apple"
        addValue(multiValueMap, "Apple", 10);
        addValue(multiValueMap, "Apple", 15);

        // Adding values to the key "Banana"
        addValue(multiValueMap, "Banana", 20);

        // Displaying the multi-value HashMap
        System.out.println("Multi-Value HashMap: " + multiValueMap);
    }

    private static void addValue(Map<String, List<Integer>> map, String key, Integer value) {
        map.computeIfAbsent(key, k -> new ArrayList<>()).add(value);
    }
}
