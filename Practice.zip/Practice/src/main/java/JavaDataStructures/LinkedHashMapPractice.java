package JavaDataStructures;

import java.util.LinkedHashMap;

public class LinkedHashMapPractice {

    public static void main(String[] args) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put(1,3);
        linkedHashMap.put(3,3);
        linkedHashMap.put(4,2);
        linkedHashMap.put(0,3);
        System.out.println(linkedHashMap);
    }
}
