package JavaDataStructures;

import java.util.LinkedHashSet;

public class LinkedHashSetPractice {

    public static void main(String[] args) {
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        linkedHashSet.add(1);
        linkedHashSet.add(3);
        linkedHashSet.add(2);
        linkedHashSet.remove(1);
        linkedHashSet.add(2);
        linkedHashSet.add(1);
        System.out.println(linkedHashSet);
    }
}
