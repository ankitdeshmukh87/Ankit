package JavaDataStructures;

import java.util.Collections;
import java.util.PriorityQueue;
/*
Read Me
1: Implemented using a heap data structure inside
2: Used to get min or map elements
3: default behavior of priority Queue is min values
 */
public class PriorityQueuePractice {

    public static void main(String[] args) {
        int[] arr = {20, 10, 60, 30, 50, 40, 70, 80, 90, 100};
        int[] minElememts = getTop5ElementsMinHeap(arr);
        int[] maxElememts = getTop5ElementsMaxHeap(arr);
        for (int num : minElememts) {
            System.out.print(num + " ");
        }
        for (int num : maxElememts) {
            System.out.print(" :: "+num + " ");
        }
    }

    public static int[] getTop5ElementsMinHeap(int[] arr) {
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();
        int[] results = new int[5];
        for(int num : arr){
            priorityQueue.add(num);
        }

        for(int i = 0 ; i < 5 ; i ++){
            results[i] = priorityQueue.poll();
        }
        return results;
    }

    public static int[] getTop5ElementsMaxHeap(int[] arr) {
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>(Collections.reverseOrder());
        int[] results = new int[5];
        for(int num : arr){
            priorityQueue.add(num);
        }

        for(int i = 0 ; i < 5 ; i ++){
            results[i] = priorityQueue.poll();
        }
        return results;
    }
}
