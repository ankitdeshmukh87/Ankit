package JavaDataStructures;
import java.util.Stack;
public class StackUsage {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack();
        int[] arr = {1,4,3,5};
        for (int num : arr){
            stack.push(num);
        }

        for(int num : stack){
            System.out.println("Stack val : " + num );
        }

        while(!stack.isEmpty()){
            System.out.println("Stackyy : " + stack.peek());
        }

    }
}
