package JavaDataStructures;

import java.util.TreeMap;

public class TreeMapPractice {

    public static void main(String[] args){
        TreeMap treeMap = new TreeMap();
        treeMap.put(1,2);
        treeMap.put(1,3);
        treeMap.put(1,0);
        treeMap.put(3,4);
        // Maintains natural order based on the keys
        System.out.println(treeMap);
    }
}
