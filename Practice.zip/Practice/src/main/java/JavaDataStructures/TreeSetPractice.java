package JavaDataStructures;

import java.util.TreeSet;

public class TreeSetPractice {

    public static void main(String[] args) {
        TreeSet<Integer> treeSet = new TreeSet();
        treeSet.add(1);
        treeSet.add(2);
        treeSet.add(0);
        // 1: Maintains natural order of elements
        System.out.println(treeSet);

    }
}
