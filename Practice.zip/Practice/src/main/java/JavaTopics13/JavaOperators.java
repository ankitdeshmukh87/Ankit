package JavaTopics13;

public class JavaOperators {

    private int value = 14;
    private int divisor = 3;
    public static void main(String[] args) {
        JavaOperators javaOperators = new JavaOperators();
        System.out.print(javaOperators.moduloCount(javaOperators.value, javaOperators.divisor));
    }
    public int moduloCount(int value, int divisor) {
        int count = 0 ;

        if(value > divisor && value%divisor != 0) {
            return value/divisor + 1;
        }
        return value/divisor;
    }

    // 1: Conditional Operators
    // int x = 5;
    //int y = (x > 3) ? 10 : 20; // if x > 3, y will be assigned 10; otherwise, y will be assigned 20


}
