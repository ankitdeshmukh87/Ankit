package LeetCode75_JulyTarget.Day1.PrefixSum;

public class FindHighestAltitude {

    public static void main(String[] args) {
        int[] gain = {-5,1,5,0,-7};
        System.out.println(findHighestAltitude(gain));
    }

    public static int findHighestAltitude(int[] altitudes) {

        int highestAltitude = 0;
        int currentAltitude = 0;
        for(int i =0 ; i < altitudes.length ; i++) {
            currentAltitude = currentAltitude + altitudes[i];
            if(currentAltitude > highestAltitude)
                highestAltitude = currentAltitude;
        }
        return highestAltitude;
    }
}
