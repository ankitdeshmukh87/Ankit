package LeetCode75_JulyTarget.Day1.SlidingWindow;

import java.util.Arrays;
import java.util.HashSet;

public class SubstringMaximumVowels {

    public static void main(String[] args) {
        String str = "abciiidef";
        int k = 3;
        System.out.println(maxVowelsString(str, k));
    }

    public static int maxVowelsString(String str, int k) {
        int maxVowels = 0 ;
        int currVowels = 0;

        HashSet<Character> vowels = new HashSet<>(Arrays.asList('a','e','i','o','u'));
        for(int i = 0; i<k; i++) {
            if(vowels.contains(str.charAt(i))) {
                maxVowels ++ ;
            }
        }

        currVowels = maxVowels;
        for(int i = k ; i < str.length(); i++) {
            if(vowels.contains(str.charAt(i)))
                currVowels++;
            if(vowels.contains(str.charAt(i -k)))
                currVowels--;
            maxVowels = Math.max(maxVowels, currVowels);
        }
        return maxVowels;
    }
}
