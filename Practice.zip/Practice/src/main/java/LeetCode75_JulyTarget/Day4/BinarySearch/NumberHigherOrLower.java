package LeetCode75_JulyTarget.Day4.BinarySearch;

public class NumberHigherOrLower {

    public static void main(String[] args){
        int n = 3;
        guessNumber(n);
    }
    public static int guessNumber(int n) {
        int left = 1;
        int right = n;

        while(left<=right){
            int mid = left + ( right - left)/2;
            int result = 4 ;//guess(mid);
            if(result == -1){
                right = mid - 1;
            } else if(result == 1){
                left = mid + 1;
            } else {
                return mid;
            }
        }
        return -1;
    }
}
