// Question 1768 : Merge String Alternately
// Topic : Two Pointer and String
package LeetCode75_JulyTarget.Day8.Strings;

public class MergeStringsAlternately {

    public static void main(String[] args){
        String word1 = "abc";
        String word2 = "pqr";
        mergedStrings(word1, word2);
        mergeAlternatelyTwoPointers(word1, word2);
    }


    // Single pointer or index method
    public static String mergedStrings(String str1, String str2) {
        StringBuilder mergedString = new StringBuilder();
        int i = 0 ;

        while (i<str1.length()||i<str2.length()){
            if(i<str1.length())
                mergedString.append(str1.charAt(i));
            if(i<str2.length())
                mergedString.append(str2.charAt(i));
            i++;
        }
        return mergedString.toString();
    }

    // Two pointer approach
    public static String mergeAlternatelyTwoPointers(String word1, String word2) {
        StringBuilder merged = new StringBuilder();
        int i = 0, j = 0;

        // Merge characters from both strings alternately
        while (i < word1.length() && j < word2.length()) {
            merged.append(word1.charAt(i++));
            merged.append(word2.charAt(j++));
        }

        // Append remaining characters of word1, if any
        while (i < word1.length()) {
            merged.append(word1.charAt(i++));
        }

        // Append remaining characters of word2, if any
        while (j < word2.length()) {
            merged.append(word2.charAt(j++));
        }

        return merged.toString();
    }
}
