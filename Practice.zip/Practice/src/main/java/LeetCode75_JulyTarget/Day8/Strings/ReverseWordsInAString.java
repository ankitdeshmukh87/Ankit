// Leetcode 151 : Reverse Words in a String

package LeetCode75_JulyTarget.Day8.Strings;

public class ReverseWordsInAString {

    public static void main(String[] args){
        String inputStr = "the sky is blue";
        System.out.println(reverseWords(inputStr));
    }

    public static String reverseWords(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        String[] words = str.trim().split("\\s+");

        for(int i = words.length - 1 ; i >=0 ; i--){
            stringBuilder.append(words[i]);
            if(i!=0)
                stringBuilder.append(" ");
        }
        return stringBuilder.toString();
    }
}
