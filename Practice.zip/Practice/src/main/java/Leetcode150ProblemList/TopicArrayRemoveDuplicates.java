package Leetcode150ProblemList;

 public class TopicArrayRemoveDuplicates {
        public int removeDuplicates(int[] nums) {
            if (nums.length == 0) return 0;

            int slow = 0;

            for (int fast = 1; fast < nums.length; fast++) {
                if (nums[fast] != nums[slow]) {
                    slow++;
                    nums[slow] = nums[fast];
                }
            }

            // The number of unique elements is slow + 1
            return slow + 1;
        }

        public static void main(String[] args) {
            TopicArrayRemoveDuplicates solution = new TopicArrayRemoveDuplicates();
            int[] nums = {0, 0, 1, 1, 1, 2, 2, 3, 3, 4};

            int k = solution.removeDuplicates(nums);

            System.out.println("Number of unique elements: " + k);
            System.out.print("Array after removing duplicates: ");
            for (int i = 0; i < k; i++) {
                System.out.print(nums[i] + " ");
            }
        }
}

