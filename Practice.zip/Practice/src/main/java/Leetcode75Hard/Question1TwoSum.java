package Leetcode75Hard;

import java.util.HashMap;

public class Question1TwoSum 
{
    public static void main(String[] args) {
        int[] nums = {0,4,3,0};
        // int[] nums = {2,7,11,15};
        int target = 0;

        int[] finalVal = twoSum(nums,target);
        for( int currVal: finalVal) {
            System.out.println(currVal);
        }
    }

    public static int[] twoSum(int[] nums, int target) {

        int[] indexArray = new int[2];
        HashMap<Integer, Integer> hashMap = new HashMap();

        for (int j =0; j< nums.length; j++) {
            hashMap.put(nums[j],j++);
        }
        hashMap.forEach((key, value) -> System.out.println());

        for (int i = 0; i < nums.length; i++) {
            int currVal = nums[i];
            if (currVal <= target) {
                int key = target - currVal;
                if (hashMap.containsKey(key) && i!= hashMap.get(key)) {
                    indexArray[0] = hashMap.get(key);
                    indexArray[1] = i;
                    break;
                }
            }
        }
        return indexArray;
    }
}