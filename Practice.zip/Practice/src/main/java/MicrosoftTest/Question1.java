package MicrosoftTest;

public class Question1 {
}
