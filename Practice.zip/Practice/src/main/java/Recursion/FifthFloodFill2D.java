package Recursion;

public class FifthFloodFill2D {

    public static void main(){
        int[][] image = {
                {1, 1, 1},
                {1, 1, 0},
                {1, 0, 1}
        };
        int x = 1;
        int y = 1;
        int originalColor = image[x][y];
        int newColor = 2;
        floodFill(image, x, y, newColor, originalColor);
    }

    public static void floodFill(int[][] image, int x, int y, int newColor, int oldColor){
        if((x < 0)||( x > image.length)||(y < 0)||(y > image[0].length)||(image[x][y]!=oldColor))
            return;
        image[x][y] = newColor;
        floodFill(image,x+1, y, newColor, oldColor);
        floodFill(image,x, y+1, newColor, oldColor);
        floodFill(image,x-1, y, newColor, oldColor);
        floodFill(image,x, y-1, newColor, oldColor);
    }
}
