package Recursion;

public class FourthCheckArrayIsSorted {
    public static void main(String[] args){

    }

    public static boolean arraySortedIterative(int[] arr){
        for(int i = 1 ; i <arr.length; i++){
            if(arr[i-1] > arr[i])
                return false;
        }
        return true;
    }

    public static boolean arraySortedRecursive(int[] arr, int index){
        if(index<=1)
            return true;
        return arr[index-2] <= arr[index-1]&& arraySortedRecursive(arr, index -1);
    }

}
