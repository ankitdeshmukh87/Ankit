package Recursion;

import java.util.HashSet;
import java.util.Set;

public class NinthNumberPermutations {

    public static void main(String[] args) {
        int number = 123; // Example number
        Set<String> permutations = new HashSet<>();
        for(int i = 0; i < 3; i++){
            System.out.println("ADD "+ String.valueOf(number).substring(0, i) + " " + String.valueOf(number).substring(i + 1, 3));
        }
        generatePermutations(String.valueOf(number), "", permutations);

        /*for (String perm : permutations) {
            System.out.println(perm);
        }*/
    }

    public static void generatePermutations(String str, String prefix, Set<String> result) {
        int n = str.length();
        if (n == 0) {
            result.add(prefix);
        } else {
            for (int i = 0; i < n; i++) {
                // System.out.println(str.substring(0, i) + " " + str.substring(i + 1, n));
                generatePermutations(
                        str.substring(0, i) + str.substring(i + 1, n),
                        prefix + str.charAt(i),
                        result
                );
            }
        }
    }
}
