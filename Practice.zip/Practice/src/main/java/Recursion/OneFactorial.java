package Recursion;
/*
3! = 1 * 2 * 3
0! = 1
1! = 1
2 = 2 * 1!
3 = 3 * 2!
4 = 4 * 3!
 */
public class OneFactorial {
    public static void main(String[] args){
        System.out.println(factorialRecursive(3));
        System.out.println(factorialIterative(3));
    }

    public static int factorialRecursive(int n){
        if(n == 0 || n == 1) return 1;
        return n * factorialRecursive(n-1);
    }

    public static int factorialIterative(int n){
        if(n == 0 || n == 1) return 1;
        int factorial = 1;
        for(int i = 1; i <= n ; i++){
            factorial = factorial * i;
        }
        return factorial;
    }
}
