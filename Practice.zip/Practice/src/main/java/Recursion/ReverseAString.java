package Recursion;

public class ReverseAString {

    public static void main(String[] args) {

        String str = "abcdef";
        char[] strArray = str.toCharArray();
        System.out.println(ReverseAString.reverseString(strArray, 0, str.length() -1));
    }

    public static String reverseString(char[] strArray, int leftPtr, int rightPtr) {
        if(leftPtr >= rightPtr) {
            return new String(strArray);
        }
        char temp = strArray[rightPtr];
        strArray[rightPtr--] = strArray[leftPtr];
        strArray[leftPtr++] = temp;
        return reverseString(strArray, leftPtr, rightPtr);
    }

}
