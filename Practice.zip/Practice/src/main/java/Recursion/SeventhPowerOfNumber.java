package Recursion;

public class SeventhPowerOfNumber {

    public static void main(String[] args){

        System.out.println(powerOfN(3, 4));
    }
    public static int powerOfN(int n, int power){
        if(power == 0) return 1;
        if(power == 1) return n;
        return n * powerOfN(n,power - 1);
    }

}
