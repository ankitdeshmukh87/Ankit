package Recursion;

public class SixthFindPathInAMaze {
    public static void main(String[] args){
        int[][] maze =
                {
                        {1, 0,  0,  0},
                        {1, 1,  1,  1},
                        {0, 1,  0,  0},
                        {1, 1,  1,  1}
                };
    }

    public static boolean isPath(int[][] maze, int rowIndex, int colIndex){
        if((rowIndex == maze.length - 1) && (colIndex == maze[0].length))
            return maze[rowIndex][colIndex] == 1;
        if (rowIndex >= 0 && rowIndex < maze.length && colIndex >= 0 && colIndex < maze[0].length && maze[rowIndex][colIndex] == 1) {
            // Move right or down
            return isPath(maze, rowIndex + 1, colIndex) || isPath(maze, rowIndex, colIndex + 1);
        }
        return false;
    }
}
