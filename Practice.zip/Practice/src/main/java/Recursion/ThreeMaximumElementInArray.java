package Recursion;

public class ThreeMaximumElementInArray {

    public static void main(String[] args){
        int[] arr = {1,4,6,8,-2,9,-7};
        System.out.println(maximumElementRecursive(arr, 0, arr[0]));
    }

    public static int maximumElementRecursive(int[] arr, int index, int currMax){
        if(arr[index] > currMax)
            currMax = arr[index];
        if(index >= arr.length - 1)
            return currMax;
        return maximumElementRecursive(arr, index + 1, currMax);
    }
}
