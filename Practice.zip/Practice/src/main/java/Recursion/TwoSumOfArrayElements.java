package Recursion;

public class TwoSumOfArrayElements {

    public static void main(String[] args) {
        int[] arr = {1,3,4,5}; // 13
        System.out.println(sumOfArrayElements(arr));
    }

    public static int sumOfArrayElements(int[] arr){
        if(arr.length == 0) return 0;
        if(arr.length == 1) return arr[0];
        int index = 0;
        return sumOfArrayHelper(arr, index);
    }
    public static int sumOfArrayHelper(int[] arr, int index){
        if(index >= arr.length){
            return 0;
        }
        return arr[index] + sumOfArrayHelper(arr, index + 1);
    }


}



