package Recursion;

public class powerOfANumber {

    static int number = 2;
    static int power = 4;
    public static void main(String[] args) {
        System.out.println(powerOfNumber(number,power));
    }
    public static int powerOfNumber(int number, int power){
        if(power == 0) return 1;
        if(power == 1) return number;
        return number * powerOfNumber(number, power-1);
    }
}
