package SortingAndSearching10;

public class MergeAndSortArray {

    public static void main(String[] args) {
        int[] A = {1,2,3};
        int[] B = new int[6];
        B[0] = 2;B[1] = 3; B[2] = 5;
        int[] finalArr = mergeSortedArray(B, A);
        for (int i: finalArr) {
            System.out.println(i);
        }
    }

    public static int[] mergeSortedArray(int[] B, int[] A) {
        int p1 = A.length - 1;
        int p2 = -1;
        int p3 = B.length - 1;

        for (int i: B) {
            if(i!=0) {
                p2++;
            }
        }
        while (p3>=0 && p2>=0 && p3>=0) {
            if (B[p2] >= B[p1]) {
                B[p3] = B[p2];
                p2--;
            } else if(B[2] < B[p1]){
                B[p3] = B[p1];
                p1--;
            }
            p3--;
        }
        return B;
    }
}
