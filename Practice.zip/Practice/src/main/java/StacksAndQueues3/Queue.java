package StacksAndQueues3;

class ListNode {
    int val;
    ListNode next;

    public ListNode(int val) {
        this.val = val;
        this.next = null;
    }
}

class Queue {
    private ListNode front;
    private ListNode rear;

    public Queue() {
        front = null;
        rear = null;
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return front == null;
    }

    // Method to enqueue an element
    public void enqueue(int val) {
        ListNode newNode = new ListNode(val);
        if (isEmpty()) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
    }

    // Method to dequeue an element
    public int dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        int dequeuedValue = front.val;
        front = front.next;
        if (front == null) {
            rear = null; // Update rear if the queue becomes empty after dequeue
        }
        return dequeuedValue;
    }

    // Method to peek at the front element of the queue
    public int peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        return front.val;
    }
    public static void main(String[] args) {
        Queue queue = new Queue();

        // Enqueue elements
        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);

        // Display front element
        System.out.println("Front element: " + queue.peek());

        // Dequeue elements and display
        System.out.println("Dequeued element: " + queue.dequeue());
        System.out.println("Dequeued element: " + queue.dequeue());

        // Enqueue more elements
        queue.enqueue(40);
        queue.enqueue(50);

        // Display front element after enqueuing
        System.out.println("Front element: " + queue.peek());

        // Dequeue elements and display
        System.out.println("Dequeued element: " + queue.dequeue());
        System.out.println("Dequeued element: " + queue.dequeue());

        // Check if queue is empty
        System.out.println("Is queue empty? " + queue.isEmpty());
    }
}

