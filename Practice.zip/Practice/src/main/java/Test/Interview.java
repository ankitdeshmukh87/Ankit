package Test;

import java.util.HashMap;
import java.util.Map;

public class Interview {

    public static void main(String[] args) {
        String str = "AaabbcdEeff";
        charCount(str);
    }
    public static void charCount(String str) {
        HashMap<Character, Integer> hashMap = new HashMap<>();
        for(char c: str.toCharArray()) {
            if(hashMap.containsKey(c)) {
                hashMap.put(c, hashMap.get(c) + 1);
            } else {
                hashMap.put(c, 1);
            }
        }
        for (Map.Entry<Character, Integer> entry : hashMap.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
    }

}
