package Test;

import java.util.HashSet;

public class OverlapArray {
    public static void main(String[] args) {
        int[] mainArr = {1,2,3,2,1};
        int[] arr2 = {1,2,3};
        int[] arr3 = {1,2,3,4};
        System.out.println(overlaps(mainArr, arr2));
        System.out.println(overlaps(mainArr, arr3));
    }
    public static boolean overlaps(int[] mainArr, int[] a) {
        HashSet<Integer> hashSet = new HashSet<>();
        for(int num : mainArr) {
            hashSet.add(num);
        }
        for(int num : a){
            if(!hashSet.contains(num)) {
                return false;
            }
        }
        return true;
    }
}
