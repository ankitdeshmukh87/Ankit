package Test;

public class SingletonClass {

}
