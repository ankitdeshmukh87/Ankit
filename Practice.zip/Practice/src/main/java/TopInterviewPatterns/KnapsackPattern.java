package TopInterviewPatterns;

public class KnapsackPattern {
}
