package TopInterviewPatterns;

public class PrefixSum {
}
