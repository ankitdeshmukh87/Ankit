package TopInterviewPatterns;

public class SlidingWindow {
}
