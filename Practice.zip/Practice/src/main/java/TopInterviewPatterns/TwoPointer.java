package TopInterviewPatterns;

public class TwoPointer {
}
