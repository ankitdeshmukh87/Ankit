package TreesAndGraphs4;

import java.util.*;

public class NaryTree<T> {
    private T data;
    private List<NaryTree<T>> children;

    public NaryTree(T data) {
        this.data = data;
        this.children = new ArrayList<>();
    }

    public void addChild(NaryTree<T> child) {
        this.children.add(child);
    }

    public T getData() {
        return data;
    }

    public List<NaryTree<T>> getChildren() {
        return children;
    }

    // Breadth-First Search
    public void bfs() {
        if (data == null) return;

        Queue<NaryTree<T>> queue = new ArrayDeque<>();
        queue.offer(this);

        while (!queue.isEmpty()) {
            NaryTree<T> current = queue.poll();
            System.out.print(current.getData() + " ");

            for (NaryTree<T> child : current.getChildren()) {
                queue.offer(child);
            }
        }
    }

    // Depth-First Search
    public void dfs() {
        dfsHelper(this);
    }

    private void dfsHelper(NaryTree<T> node) {
        if (node == null) return;

        System.out.print(node.getData() + " ");

        for (NaryTree<T> child : node.getChildren()) {
            dfsHelper(child);
        }
    }

    public static void main(String[] args) {
        // Creating an example n-ary tree
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        minHeap.peek();
        Stack<Integer> stack = new Stack<>();
        StringBuilder sb = new StringBuilder();
        NaryTree<String> tree = new NaryTree<>("A");

        NaryTree<String> root = tree;
        root.addChild(new NaryTree<>("B"));
        root.addChild(new NaryTree<>("C"));
        NaryTree<String> dNode = new NaryTree<>("D");
        root.addChild(dNode);
        dNode.addChild(new NaryTree<>("E"));
        dNode.addChild(new NaryTree<>("F"));

        // BFS
        System.out.println("BFS traversal:");
        root.bfs();
        System.out.println();

        // DFS
        System.out.println("DFS traversal:");
        root.dfs();
        System.out.println();
    }
}
