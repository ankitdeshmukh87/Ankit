package TreesAndGraphs4;
/*
We maintain a boolean array visited to keep track of visited nodes to avoid revisiting them during traversal.
In both BFS and DFS, we traverse the tree while checking the visited array to ensure that each node is visited only once.
The indexOf method is used to find the index of a child node within the list of children.
The traversal logic remains the same as before, but we need to handle the undirected nature of the tree by marking visited nodes appropriately.
 */

import java.util.ArrayDeque;
        import java.util.ArrayList;
        import java.util.List;
        import java.util.Queue;

public class NaryTreeUndirected<T> {
    private T data;
    private List<NaryTreeUndirected<T>> children;

    public NaryTreeUndirected(T data) {
        this.data = data;
        this.children = new ArrayList<>();
    }

    public void addChild(NaryTreeUndirected<T> child) {
        this.children.add(child);
    }

    public T getData() {
        return data;
    }

    public List<NaryTreeUndirected<T>> getChildren() {
        return children;
    }

    // Breadth-First Search
    public void bfs() {
        if (data == null) return;

        Queue<NaryTreeUndirected<T>> queue = new ArrayDeque<>();
        boolean[] visited = new boolean[children.size()];

        queue.offer(this);
        visited[children.indexOf(this)] = true;

        while (!queue.isEmpty()) {
            NaryTreeUndirected<T> current = queue.poll();
            System.out.print(current.getData() + " ");

            for (NaryTreeUndirected<T> child : current.getChildren()) {
                int index = children.indexOf(child);
                if (!visited[index]) {
                    queue.offer(child);
                    visited[index] = true;
                }
            }
        }
    }

    // Depth-First Search
    public void dfs() {
        dfsHelper(this, new boolean[children.size()]);
    }

    private void dfsHelper(NaryTreeUndirected<T> node, boolean[] visited) {
        if (node == null) return;

        System.out.print(node.getData() + " ");
        visited[children.indexOf(node)] = true;

        for (NaryTreeUndirected<T> child : node.getChildren()) {
            int index = children.indexOf(child);
            if (!visited[index]) {
                dfsHelper(child, visited);
            }
        }
    }

    public static void main(String[] args) {
        // Creating an example undirected n-ary tree
        NaryTreeUndirected<String> tree = new NaryTreeUndirected<>("A");

        NaryTreeUndirected<String> root = tree;
        NaryTreeUndirected<String> bNode = new NaryTreeUndirected<>("B");
        NaryTreeUndirected<String> cNode = new NaryTreeUndirected<>("C");
        NaryTreeUndirected<String> dNode = new NaryTreeUndirected<>("D");

        root.addChild(bNode);
        root.addChild(cNode);
        root.addChild(dNode);

        bNode.addChild(new NaryTreeUndirected<>("E"));
        bNode.addChild(new NaryTreeUndirected<>("F"));
        cNode.addChild(new NaryTreeUndirected<>("G"));
        dNode.addChild(new NaryTreeUndirected<>("H"));

        // BFS
        System.out.println("BFS traversal:");
        root.bfs();
        System.out.println();

        // DFS
        System.out.println("DFS traversal:");
        root.dfs();
        System.out.println();
    }
}

