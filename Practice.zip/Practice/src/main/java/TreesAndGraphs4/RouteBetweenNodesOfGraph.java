package TreesAndGraphs4;

import java.util.LinkedList;
import java.util.Queue;

public class RouteBetweenNodesOfGraph {

    public static void main(String[] args) {
        Graph graph = new Graph(5);
        System.out.println(isRouteExists(1,2,5,graph.getGraph(5)));
    }

    public static boolean isRouteExists(int start, int end, int vertices, Graph graph) {
        boolean[] visited = new boolean[vertices];
        Queue<Integer> queue = new LinkedList<>();
        visited[start] = true;
        queue.offer(start);

        while(!queue.isEmpty()) {
            int current = queue.poll();
            if(end == current) return true;
            for(int neighbor : graph.adjList.get(current)) {
                if(!visited[neighbor]) {
                    visited[neighbor] = true;
                    queue.offer(neighbor);
                }
            }
        }
        return false;
    }
}
