package TwoPointer;

/*

392. Is Subsequence
Given two strings s and t, return true if s is a subsequence of t, or false otherwise.

A subsequence of a string is a new string that is formed from the original string by deleting some (can be none) of the
characters without disturbing the relative positions of the remaining characters. (i.e., "ace" is a subsequence of "abcde" while "aec" is not).
 */
public class CheckIfSubsequence {
    String s = "abc";
    String t = "ahbgdc";

    public static void main(String[] args){

    }
    public static boolean isSubsequence(String s, String t){
        int i = 0;
        int j = 0;

        while(j < t.length()) {
            if(i < s.length() && t.charAt(j) == s.charAt(i)){
                i++;
            }
            j++;
        }

        return i == s.length();
    }
}
